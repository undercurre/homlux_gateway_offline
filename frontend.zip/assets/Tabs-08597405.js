import{g as M,r as z,bG as bt,h as l,A as ct,D as we,aJ as ft,j as q,q as pt,a7 as ut,N as vt,bH as ht,bC as gt,bI as xt,b as r,d as o,e as u,x as _,aF as mt,u as yt,k as Ce,aH as ee,i as te,o as wt,z as Ct,t as B,w as St,as as k,bJ as K,n as Rt,aL as ve,bK as ae,bL as zt,aK as Y,bD as $t,v as re,X as Tt,Y as Pt,bM as _t,bN as Wt}from"./index-e9a0fbbf.js";import{c as Lt,a as he,u as ge,o as At}from"./cssr-d6c394cf.js";import{u as Bt}from"./Input-ab376585.js";import{t as ne}from"./throttle-8ccb85cf.js";const kt=he(".v-x-scroll",{overflow:"auto",scrollbarWidth:"none"},[he("&::-webkit-scrollbar",{width:0,height:0})]),Et=M({name:"XScroll",props:{disabled:Boolean,onScroll:Function},setup(){const e=z(null);function s(d){!(d.currentTarget.offsetWidth<d.currentTarget.scrollWidth)||d.deltaY===0||(d.currentTarget.scrollLeft+=d.deltaY+d.deltaX,d.preventDefault())}const c=bt();return kt.mount({id:"vueuc/x-scroll",head:!0,anchorMetaName:Lt,ssr:c}),Object.assign({selfRef:e,handleWheel:s},{scrollTo(...d){var m;(m=e.value)===null||m===void 0||m.scrollTo(...d)}})},render(){return l("div",{ref:"selfRef",onScroll:this.onScroll,onWheel:this.disabled?void 0:this.handleWheel,class:"v-x-scroll"},this.$slots)}}),jt=M({name:"Add",render(){return l("svg",{width:"512",height:"512",viewBox:"0 0 512 512",fill:"none",xmlns:"http://www.w3.org/2000/svg"},l("path",{d:"M256 112V400M400 256H112",stroke:"currentColor","stroke-width":"32","stroke-linecap":"round","stroke-linejoin":"round"}))}}),ie=ct("n-tabs"),Se={tab:[String,Number,Object,Function],name:{type:[String,Number],required:!0},disabled:Boolean,displayDirective:{type:String,default:"if"},closable:{type:Boolean,default:void 0},tabProps:Object,label:[String,Number,Object,Function]},Nt=M({__TAB_PANE__:!0,name:"TabPane",alias:["TabPanel"],props:Se,setup(e){const s=we(ie,null);return s||ft("tab-pane","`n-tab-pane` must be placed inside `n-tabs`."),{style:s.paneStyleRef,class:s.paneClassRef,mergedClsPrefix:s.mergedClsPrefixRef}},render(){return l("div",{class:[`${this.mergedClsPrefix}-tab-pane`,this.class],style:this.style},this.$slots)}}),Ht=Object.assign({internalLeftPadded:Boolean,internalAddable:Boolean,internalCreatedByPane:Boolean},xt(Se,["displayDirective"])),se=M({__TAB__:!0,inheritAttrs:!1,name:"Tab",props:Ht,setup(e){const{mergedClsPrefixRef:s,valueRef:c,typeRef:y,closableRef:d,tabStyleRef:m,addTabStyleRef:v,tabClassRef:w,addTabClassRef:C,tabChangeIdRef:h,onBeforeLeaveRef:f,triggerRef:j,handleAdd:W,activateTab:g,handleClose:S}=we(ie);return{trigger:j,mergedClosable:q(()=>{if(e.internalAddable)return!1;const{closable:x}=e;return x===void 0?d.value:x}),style:m,addStyle:v,tabClass:w,addTabClass:C,clsPrefix:s,value:c,type:y,handleClose(x){x.stopPropagation(),!e.disabled&&S(e.name)},activateTab(){if(e.disabled)return;if(e.internalAddable){W();return}const{name:x}=e,T=++h.id;if(x!==c.value){const{value:L}=f;L?Promise.resolve(L(e.name,c.value)).then($=>{$&&h.id===T&&g(x)}):g(x)}}}},render(){const{internalAddable:e,clsPrefix:s,name:c,disabled:y,label:d,tab:m,value:v,mergedClosable:w,trigger:C,$slots:{default:h}}=this,f=d??m;return l("div",{class:`${s}-tabs-tab-wrapper`},this.internalLeftPadded?l("div",{class:`${s}-tabs-tab-pad`}):null,l("div",Object.assign({key:c,"data-name":c,"data-disabled":y?!0:void 0},pt({class:[`${s}-tabs-tab`,v===c&&`${s}-tabs-tab--active`,y&&`${s}-tabs-tab--disabled`,w&&`${s}-tabs-tab--closable`,e&&`${s}-tabs-tab--addable`,e?this.addTabClass:this.tabClass],onClick:C==="click"?this.activateTab:void 0,onMouseenter:C==="hover"?this.activateTab:void 0,style:e?this.addStyle:this.style},this.internalCreatedByPane?this.tabProps||{}:this.$attrs)),l("span",{class:`${s}-tabs-tab__label`},e?l(ut,null,l("div",{class:`${s}-tabs-tab__height-placeholder`}," "),l(vt,{clsPrefix:s},{default:()=>l(jt,null)})):h?h():typeof f=="object"?f:ht(f??c)),w&&this.type==="card"?l(gt,{clsPrefix:s,class:`${s}-tabs-tab__close`,onClick:this.handleClose,disabled:y}):null))}}),Ot=r("tabs",`
 box-sizing: border-box;
 width: 100%;
 display: flex;
 flex-direction: column;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[o("segment-type",[r("tabs-rail",[u("&.transition-disabled",[r("tabs-capsule",`
 transition: none;
 `)])])]),o("top",[r("tab-pane",`
 padding: var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left);
 `)]),o("left",[r("tab-pane",`
 padding: var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left) var(--n-pane-padding-top);
 `)]),o("left, right",`
 flex-direction: row;
 `,[r("tabs-bar",`
 width: 2px;
 right: 0;
 transition:
 top .2s var(--n-bezier),
 max-height .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),r("tabs-tab",`
 padding: var(--n-tab-padding-vertical); 
 `)]),o("right",`
 flex-direction: row-reverse;
 `,[r("tab-pane",`
 padding: var(--n-pane-padding-left) var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom);
 `),r("tabs-bar",`
 left: 0;
 `)]),o("bottom",`
 flex-direction: column-reverse;
 justify-content: flex-end;
 `,[r("tab-pane",`
 padding: var(--n-pane-padding-bottom) var(--n-pane-padding-right) var(--n-pane-padding-top) var(--n-pane-padding-left);
 `),r("tabs-bar",`
 top: 0;
 `)]),r("tabs-rail",`
 padding: 3px;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 background-color: var(--n-color-segment);
 transition: background-color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[r("tabs-capsule",`
 border-radius: var(--n-tab-border-radius);
 position: absolute;
 pointer-events: none;
 background-color: var(--n-tab-color-segment);
 box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .08);
 transition: transform 0.3s var(--n-bezier);
 `),r("tabs-tab-wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[r("tabs-tab",`
 overflow: hidden;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[o("active",`
 font-weight: var(--n-font-weight-strong);
 color: var(--n-tab-text-color-active);
 `),u("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])])]),o("flex",[r("tabs-nav",`
 width: 100%;
 position: relative;
 `,[r("tabs-wrapper",`
 width: 100%;
 `,[r("tabs-tab",`
 margin-right: 0;
 `)])])]),r("tabs-nav",`
 box-sizing: border-box;
 line-height: 1.5;
 display: flex;
 transition: border-color .3s var(--n-bezier);
 `,[_("prefix, suffix",`
 display: flex;
 align-items: center;
 `),_("prefix","padding-right: 16px;"),_("suffix","padding-left: 16px;")]),o("top, bottom",[r("tabs-nav-scroll-wrapper",[u("&::before",`
 top: 0;
 bottom: 0;
 left: 0;
 width: 20px;
 `),u("&::after",`
 top: 0;
 bottom: 0;
 right: 0;
 width: 20px;
 `),o("shadow-start",[u("&::before",`
 box-shadow: inset 10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),o("shadow-end",[u("&::after",`
 box-shadow: inset -10px 0 8px -8px rgba(0, 0, 0, .12);
 `)])])]),o("left, right",[r("tabs-nav-scroll-content",`
 flex-direction: column;
 `),r("tabs-nav-scroll-wrapper",[u("&::before",`
 top: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),u("&::after",`
 bottom: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),o("shadow-start",[u("&::before",`
 box-shadow: inset 0 10px 8px -8px rgba(0, 0, 0, .12);
 `)]),o("shadow-end",[u("&::after",`
 box-shadow: inset 0 -10px 8px -8px rgba(0, 0, 0, .12);
 `)])])]),r("tabs-nav-scroll-wrapper",`
 flex: 1;
 position: relative;
 overflow: hidden;
 `,[r("tabs-nav-y-scroll",`
 height: 100%;
 width: 100%;
 overflow-y: auto; 
 scrollbar-width: none;
 `,[u("&::-webkit-scrollbar",`
 width: 0;
 height: 0;
 `)]),u("&::before, &::after",`
 transition: box-shadow .3s var(--n-bezier);
 pointer-events: none;
 content: "";
 position: absolute;
 z-index: 1;
 `)]),r("tabs-nav-scroll-content",`
 display: flex;
 position: relative;
 min-width: 100%;
 min-height: 100%;
 width: fit-content;
 box-sizing: border-box;
 `),r("tabs-wrapper",`
 display: inline-flex;
 flex-wrap: nowrap;
 position: relative;
 `),r("tabs-tab-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 flex-shrink: 0;
 flex-grow: 0;
 `),r("tabs-tab",`
 cursor: pointer;
 white-space: nowrap;
 flex-wrap: nowrap;
 display: inline-flex;
 align-items: center;
 color: var(--n-tab-text-color);
 font-size: var(--n-tab-font-size);
 background-clip: padding-box;
 padding: var(--n-tab-padding);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[o("disabled",{cursor:"not-allowed"}),_("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),_("label",`
 display: flex;
 align-items: center;
 z-index: 1;
 `)]),r("tabs-bar",`
 position: absolute;
 bottom: 0;
 height: 2px;
 border-radius: 1px;
 background-color: var(--n-bar-color);
 transition:
 left .2s var(--n-bezier),
 max-width .2s var(--n-bezier),
 opacity .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[u("&.transition-disabled",`
 transition: none;
 `),o("disabled",`
 background-color: var(--n-tab-text-color-disabled)
 `)]),r("tabs-pane-wrapper",`
 position: relative;
 overflow: hidden;
 transition: max-height .2s var(--n-bezier);
 `),r("tab-pane",`
 color: var(--n-pane-text-color);
 width: 100%;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 opacity .2s var(--n-bezier);
 left: 0;
 right: 0;
 top: 0;
 `,[u("&.next-transition-leave-active, &.prev-transition-leave-active, &.next-transition-enter-active, &.prev-transition-enter-active",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 transform .2s var(--n-bezier),
 opacity .2s var(--n-bezier);
 `),u("&.next-transition-leave-active, &.prev-transition-leave-active",`
 position: absolute;
 `),u("&.next-transition-enter-from, &.prev-transition-leave-to",`
 transform: translateX(32px);
 opacity: 0;
 `),u("&.next-transition-leave-to, &.prev-transition-enter-from",`
 transform: translateX(-32px);
 opacity: 0;
 `),u("&.next-transition-leave-from, &.next-transition-enter-to, &.prev-transition-leave-from, &.prev-transition-enter-to",`
 transform: translateX(0);
 opacity: 1;
 `)]),r("tabs-tab-pad",`
 box-sizing: border-box;
 width: var(--n-tab-gap);
 flex-grow: 0;
 flex-shrink: 0;
 `),o("line-type, bar-type",[r("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 box-sizing: border-box;
 vertical-align: bottom;
 `,[u("&:hover",{color:"var(--n-tab-text-color-hover)"}),o("active",`
 color: var(--n-tab-text-color-active);
 font-weight: var(--n-tab-font-weight-active);
 `),o("disabled",{color:"var(--n-tab-text-color-disabled)"})])]),r("tabs-nav",[o("line-type",[o("top",[_("prefix, suffix",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 bottom: -1px;
 `)]),o("left",[_("prefix, suffix",`
 border-right: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-right: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 right: -1px;
 `)]),o("right",[_("prefix, suffix",`
 border-left: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-left: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 left: -1px;
 `)]),o("bottom",[_("prefix, suffix",`
 border-top: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-top: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 top: -1px;
 `)]),_("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-nav-scroll-content",`
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-bar",`
 border-radius: 0;
 `)]),o("card-type",[_("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-pad",`
 flex-grow: 1;
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-tab-pad",`
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 border: 1px solid var(--n-tab-border-color);
 background-color: var(--n-tab-color);
 box-sizing: border-box;
 position: relative;
 vertical-align: bottom;
 display: flex;
 justify-content: space-between;
 font-size: var(--n-tab-font-size);
 color: var(--n-tab-text-color);
 `,[o("addable",`
 padding-left: 8px;
 padding-right: 8px;
 font-size: 16px;
 `,[_("height-placeholder",`
 width: 0;
 font-size: var(--n-tab-font-size);
 `),mt("disabled",[u("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])]),o("closable","padding-right: 8px;"),o("active",`
 background-color: #0000;
 font-weight: var(--n-tab-font-weight-active);
 color: var(--n-tab-text-color-active);
 `),o("disabled","color: var(--n-tab-text-color-disabled);")]),r("tabs-scroll-padding","border-bottom: 1px solid var(--n-tab-border-color);")]),o("left, right",[r("tabs-wrapper",`
 flex-direction: column;
 `,[r("tabs-tab-wrapper",`
 flex-direction: column;
 `,[r("tabs-tab-pad",`
 height: var(--n-tab-gap-vertical);
 width: 100%;
 `)])])]),o("top",[o("card-type",[r("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-top-right-radius: var(--n-tab-border-radius);
 `,[o("active",`
 border-bottom: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `)])]),o("left",[o("card-type",[r("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-bottom-left-radius: var(--n-tab-border-radius);
 `,[o("active",`
 border-right: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `),r("tabs-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `)])]),o("right",[o("card-type",[r("tabs-tab",`
 border-top-right-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[o("active",`
 border-left: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `),r("tabs-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `)])]),o("bottom",[o("card-type",[r("tabs-tab",`
 border-bottom-left-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[o("active",`
 border-top: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `),r("tabs-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `)])])])]),Ft=Object.assign(Object.assign({},Ce.props),{value:[String,Number],defaultValue:[String,Number],trigger:{type:String,default:"click"},type:{type:String,default:"bar"},closable:Boolean,justifyContent:String,size:{type:String,default:"medium"},placement:{type:String,default:"top"},tabStyle:[String,Object],tabClass:String,addTabStyle:[String,Object],addTabClass:String,barWidth:Number,paneClass:String,paneStyle:[String,Object],paneWrapperClass:String,paneWrapperStyle:[String,Object],addable:[Boolean,Object],tabsPadding:{type:Number,default:0},animated:Boolean,onBeforeLeave:Function,onAdd:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClose:[Function,Array],labelSize:String,activeName:[String,Number],onActiveNameChange:[Function,Array]}),Xt=M({name:"Tabs",props:Ft,setup(e,{slots:s}){var c,y,d,m;const{mergedClsPrefixRef:v,inlineThemeDisabled:w}=yt(e),C=Ce("Tabs","-tabs",Ot,zt,e,v),h=z(null),f=z(null),j=z(null),W=z(null),g=z(null),S=z(null),x=z(!0),T=z(!0),L=ge(e,["labelSize","size"]),$=ge(e,["activeName","value"]),D=z((y=(c=$.value)!==null&&c!==void 0?c:e.defaultValue)!==null&&y!==void 0?y:s.default?(m=(d=ee(s.default())[0])===null||d===void 0?void 0:d.props)===null||m===void 0?void 0:m.name:null),P=Bt($,D),b={id:0},R=q(()=>{if(!(!e.justifyContent||e.type==="card"))return{display:"flex",justifyContent:e.justifyContent}});te(P,()=>{b.id=0,V(),de()});function H(){var a;const{value:t}=P;return t===null?null:(a=h.value)===null||a===void 0?void 0:a.querySelector(`[data-name="${t}"]`)}function Re(a){if(e.type==="card")return;const{value:t}=f;if(!t)return;const n=t.style.opacity==="0";if(a){const i=`${v.value}-tabs-bar--disabled`,{barWidth:p,placement:E}=e;if(a.dataset.disabled==="true"?t.classList.add(i):t.classList.remove(i),["top","bottom"].includes(E)){if(le(["top","maxHeight","height"]),typeof p=="number"&&a.offsetWidth>=p){const A=Math.floor((a.offsetWidth-p)/2)+a.offsetLeft;t.style.left=`${A}px`,t.style.maxWidth=`${p}px`}else t.style.left=`${a.offsetLeft}px`,t.style.maxWidth=`${a.offsetWidth}px`;t.style.width="8192px",n&&(t.style.transition="none"),t.offsetWidth,n&&(t.style.transition="",t.style.opacity="1")}else{if(le(["left","maxWidth","width"]),typeof p=="number"&&a.offsetHeight>=p){const A=Math.floor((a.offsetHeight-p)/2)+a.offsetTop;t.style.top=`${A}px`,t.style.maxHeight=`${p}px`}else t.style.top=`${a.offsetTop}px`,t.style.maxHeight=`${a.offsetHeight}px`;t.style.height="8192px",n&&(t.style.transition="none"),t.offsetHeight,n&&(t.style.transition="",t.style.opacity="1")}}}function ze(){if(e.type==="card")return;const{value:a}=f;a&&(a.style.opacity="0")}function le(a){const{value:t}=f;if(t)for(const n of a)t.style[n]=""}function V(){if(e.type==="card")return;const a=H();a?Re(a):ze()}function de(a){var t;const n=(t=g.value)===null||t===void 0?void 0:t.$el;if(!n)return;const i=H();if(!i)return;const{scrollLeft:p,offsetWidth:E}=n,{offsetLeft:A,offsetWidth:G}=i;p>A?n.scrollTo({top:0,left:A,behavior:"smooth"}):A+G>p+E&&n.scrollTo({top:0,left:A+G-E,behavior:"smooth"})}const N=z(null);let J=0,O=null;function $e(a){const t=N.value;if(t){J=a.getBoundingClientRect().height;const n=`${J}px`,i=()=>{t.style.height=n,t.style.maxHeight=n};O?(i(),O(),O=null):O=i}}function Te(a){const t=N.value;if(t){const n=a.getBoundingClientRect().height,i=()=>{document.body.offsetHeight,t.style.maxHeight=`${n}px`,t.style.height=`${Math.max(J,n)}px`};O?(O(),O=null,i()):O=i}}function Pe(){const a=N.value;if(a){a.style.maxHeight="",a.style.height="";const{paneWrapperStyle:t}=e;if(typeof t=="string")a.style.cssText=t;else if(t){const{maxHeight:n,height:i}=t;n!==void 0&&(a.style.maxHeight=n),i!==void 0&&(a.style.height=i)}}}const be={value:[]},ce=z("next");function _e(a){const t=P.value;let n="next";for(const i of be.value){if(i===t)break;if(i===a){n="prev";break}}ce.value=n,We(a)}function We(a){const{onActiveNameChange:t,onUpdateValue:n,"onUpdate:value":i}=e;t&&Y(t,a),n&&Y(n,a),i&&Y(i,a),D.value=a}function Le(a){const{onClose:t}=e;t&&Y(t,a)}function fe(){const{value:a}=f;if(!a)return;const t="transition-disabled";a.classList.add(t),V(),a.classList.remove(t)}const F=z(null);function Q({transitionDisabled:a}){const t=h.value;if(!t)return;a&&t.classList.add("transition-disabled");const n=H();n&&F.value&&(F.value.style.width=`${n.offsetWidth}px`,F.value.style.height=`${n.offsetHeight}px`,F.value.style.transform=`translateX(${n.offsetLeft-t.offsetLeft-$t(getComputedStyle(t).paddingLeft)}px)`,a&&F.value.offsetWidth),a&&t.classList.remove("transition-disabled")}te([P],()=>{e.type==="segment"&&re(()=>{Q({transitionDisabled:!1})})}),wt(()=>{e.type==="segment"&&Q({transitionDisabled:!0})});let pe=0;function Ae(a){var t;if(a.contentRect.width===0&&a.contentRect.height===0||pe===a.contentRect.width)return;pe=a.contentRect.width;const{type:n}=e;if((n==="line"||n==="bar")&&fe(),n!=="segment"){const{placement:i}=e;Z((i==="top"||i==="bottom"?(t=g.value)===null||t===void 0?void 0:t.$el:S.value)||null)}}const Be=ne(Ae,64);te([()=>e.justifyContent,()=>e.size],()=>{re(()=>{const{type:a}=e;(a==="line"||a==="bar")&&fe()})});const X=z(!1);function ke(a){var t;const{target:n,contentRect:{width:i}}=a,p=n.parentElement.offsetWidth;if(!X.value)p<i&&(X.value=!0);else{const{value:E}=W;if(!E)return;p-i>E.$el.offsetWidth&&(X.value=!1)}Z(((t=g.value)===null||t===void 0?void 0:t.$el)||null)}const Ee=ne(ke,64);function je(){const{onAdd:a}=e;a&&a(),re(()=>{const t=H(),{value:n}=g;!t||!n||n.scrollTo({left:t.offsetLeft,top:0,behavior:"smooth"})})}function Z(a){if(!a)return;const{placement:t}=e;if(t==="top"||t==="bottom"){const{scrollLeft:n,scrollWidth:i,offsetWidth:p}=a;x.value=n<=0,T.value=n+p>=i}else{const{scrollTop:n,scrollHeight:i,offsetHeight:p}=a;x.value=n<=0,T.value=n+p>=i}}const He=ne(a=>{Z(a.target)},64);Ct(ie,{triggerRef:B(e,"trigger"),tabStyleRef:B(e,"tabStyle"),tabClassRef:B(e,"tabClass"),addTabStyleRef:B(e,"addTabStyle"),addTabClassRef:B(e,"addTabClass"),paneClassRef:B(e,"paneClass"),paneStyleRef:B(e,"paneStyle"),mergedClsPrefixRef:v,typeRef:B(e,"type"),closableRef:B(e,"closable"),valueRef:P,tabChangeIdRef:b,onBeforeLeaveRef:B(e,"onBeforeLeave"),activateTab:_e,handleClose:Le,handleAdd:je}),At(()=>{V(),de()}),St(()=>{const{value:a}=j;if(!a)return;const{value:t}=v,n=`${t}-tabs-nav-scroll-wrapper--shadow-start`,i=`${t}-tabs-nav-scroll-wrapper--shadow-end`;x.value?a.classList.remove(n):a.classList.add(n),T.value?a.classList.remove(i):a.classList.add(i)});const Oe={syncBarPosition:()=>{V()}},Fe=()=>{Q({transitionDisabled:!0})},ue=q(()=>{const{value:a}=L,{type:t}=e,n={card:"Card",bar:"Bar",line:"Line",segment:"Segment"}[t],i=`${a}${n}`,{self:{barColor:p,closeIconColor:E,closeIconColorHover:A,closeIconColorPressed:G,tabColor:Ie,tabBorderColor:De,paneTextColor:Me,tabFontWeight:Ve,tabBorderRadius:Ne,tabFontWeightActive:Xe,colorSegment:Ge,fontWeightStrong:Ue,tabColorSegment:Ke,closeSize:Ye,closeIconSize:qe,closeColorHover:Je,closeColorPressed:Qe,closeBorderRadius:Ze,[k("panePadding",a)]:U,[k("tabPadding",i)]:et,[k("tabPaddingVertical",i)]:tt,[k("tabGap",i)]:at,[k("tabGap",`${i}Vertical`)]:rt,[k("tabTextColor",t)]:nt,[k("tabTextColorActive",t)]:ot,[k("tabTextColorHover",t)]:st,[k("tabTextColorDisabled",t)]:it,[k("tabFontSize",a)]:lt},common:{cubicBezierEaseInOut:dt}}=C.value;return{"--n-bezier":dt,"--n-color-segment":Ge,"--n-bar-color":p,"--n-tab-font-size":lt,"--n-tab-text-color":nt,"--n-tab-text-color-active":ot,"--n-tab-text-color-disabled":it,"--n-tab-text-color-hover":st,"--n-pane-text-color":Me,"--n-tab-border-color":De,"--n-tab-border-radius":Ne,"--n-close-size":Ye,"--n-close-icon-size":qe,"--n-close-color-hover":Je,"--n-close-color-pressed":Qe,"--n-close-border-radius":Ze,"--n-close-icon-color":E,"--n-close-icon-color-hover":A,"--n-close-icon-color-pressed":G,"--n-tab-color":Ie,"--n-tab-font-weight":Ve,"--n-tab-font-weight-active":Xe,"--n-tab-padding":et,"--n-tab-padding-vertical":tt,"--n-tab-gap":at,"--n-tab-gap-vertical":rt,"--n-pane-padding-left":K(U,"left"),"--n-pane-padding-right":K(U,"right"),"--n-pane-padding-top":K(U,"top"),"--n-pane-padding-bottom":K(U,"bottom"),"--n-font-weight-strong":Ue,"--n-tab-color-segment":Ke}}),I=w?Rt("tabs",q(()=>`${L.value[0]}${e.type[0]}`),ue,e):void 0;return Object.assign({mergedClsPrefix:v,mergedValue:P,renderedNames:new Set,segmentCapsuleElRef:F,tabsPaneWrapperRef:N,tabsElRef:h,barElRef:f,addTabInstRef:W,xScrollInstRef:g,scrollWrapperElRef:j,addTabFixed:X,tabWrapperStyle:R,handleNavResize:Be,mergedSize:L,handleScroll:He,handleTabsResize:Ee,cssVars:w?void 0:ue,themeClass:I==null?void 0:I.themeClass,animationDirection:ce,renderNameListRef:be,yScrollElRef:S,handleSegmentResize:Fe,onAnimationBeforeLeave:$e,onAnimationEnter:Te,onAnimationAfterEnter:Pe,onRender:I==null?void 0:I.onRender},Oe)},render(){const{mergedClsPrefix:e,type:s,placement:c,addTabFixed:y,addable:d,mergedSize:m,renderNameListRef:v,onRender:w,paneWrapperClass:C,paneWrapperStyle:h,$slots:{default:f,prefix:j,suffix:W}}=this;w==null||w();const g=f?ee(f()).filter(b=>b.type.__TAB_PANE__===!0):[],S=f?ee(f()).filter(b=>b.type.__TAB__===!0):[],x=!S.length,T=s==="card",L=s==="segment",$=!T&&!L&&this.justifyContent;v.value=[];const D=()=>{const b=l("div",{style:this.tabWrapperStyle,class:[`${e}-tabs-wrapper`]},$?null:l("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}),x?g.map((R,H)=>(v.value.push(R.props.name),oe(l(se,Object.assign({},R.props,{internalCreatedByPane:!0,internalLeftPadded:H!==0&&(!$||$==="center"||$==="start"||$==="end")}),R.children?{default:R.children.tab}:void 0)))):S.map((R,H)=>(v.value.push(R.props.name),oe(H!==0&&!$?ye(R):R))),!y&&d&&T?me(d,(x?g.length:S.length)!==0):null,$?null:l("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}));return l("div",{ref:"tabsElRef",class:`${e}-tabs-nav-scroll-content`},T&&d?l(ae,{onResize:this.handleTabsResize},{default:()=>b}):b,T?l("div",{class:`${e}-tabs-pad`}):null,T?null:l("div",{ref:"barElRef",class:`${e}-tabs-bar`}))},P=L?"top":c;return l("div",{class:[`${e}-tabs`,this.themeClass,`${e}-tabs--${s}-type`,`${e}-tabs--${m}-size`,$&&`${e}-tabs--flex`,`${e}-tabs--${P}`],style:this.cssVars},l("div",{class:[`${e}-tabs-nav--${s}-type`,`${e}-tabs-nav--${P}`,`${e}-tabs-nav`]},ve(j,b=>b&&l("div",{class:`${e}-tabs-nav__prefix`},b)),L?l(ae,{onResize:this.handleSegmentResize},{default:()=>l("div",{class:`${e}-tabs-rail`,ref:"tabsElRef"},l("div",{class:`${e}-tabs-capsule`,ref:"segmentCapsuleElRef"},l("div",{class:`${e}-tabs-wrapper`},l("div",{class:`${e}-tabs-tab`}))),x?g.map((b,R)=>(v.value.push(b.props.name),l(se,Object.assign({},b.props,{internalCreatedByPane:!0,internalLeftPadded:R!==0}),b.children?{default:b.children.tab}:void 0))):S.map((b,R)=>(v.value.push(b.props.name),R===0?b:ye(b))))}):l(ae,{onResize:this.handleNavResize},{default:()=>l("div",{class:`${e}-tabs-nav-scroll-wrapper`,ref:"scrollWrapperElRef"},["top","bottom"].includes(P)?l(Et,{ref:"xScrollInstRef",onScroll:this.handleScroll},{default:D}):l("div",{class:`${e}-tabs-nav-y-scroll`,onScroll:this.handleScroll,ref:"yScrollElRef"},D()))}),y&&d&&T?me(d,!0):null,ve(W,b=>b&&l("div",{class:`${e}-tabs-nav__suffix`},b))),x&&(this.animated&&(P==="top"||P==="bottom")?l("div",{ref:"tabsPaneWrapperRef",style:h,class:[`${e}-tabs-pane-wrapper`,C]},xe(g,this.mergedValue,this.renderedNames,this.onAnimationBeforeLeave,this.onAnimationEnter,this.onAnimationAfterEnter,this.animationDirection)):xe(g,this.mergedValue,this.renderedNames)))}});function xe(e,s,c,y,d,m,v){const w=[];return e.forEach(C=>{const{name:h,displayDirective:f,"display-directive":j}=C.props,W=S=>f===S||j===S,g=s===h;if(C.key!==void 0&&(C.key=h),g||W("show")||W("show:lazy")&&c.has(h)){c.has(h)||c.add(h);const S=!W("if");w.push(S?Tt(C,[[Pt,g]]):C)}}),v?l(_t,{name:`${v}-transition`,onBeforeLeave:y,onEnter:d,onAfterEnter:m},{default:()=>w}):w}function me(e,s){return l(se,{ref:"addTabInstRef",key:"__addable",name:"__addable",internalCreatedByPane:!0,internalAddable:!0,internalLeftPadded:s,disabled:typeof e=="object"&&e.disabled})}function ye(e){const s=Wt(e);return s.props?s.props.internalLeftPadded=!0:s.props={internalLeftPadded:!0},s}function oe(e){return Array.isArray(e.dynamicProps)?e.dynamicProps.includes("internalLeftPadded")||e.dynamicProps.push("internalLeftPadded"):e.dynamicProps=["internalLeftPadded"],e}export{jt as A,Xt as _,Nt as a};
