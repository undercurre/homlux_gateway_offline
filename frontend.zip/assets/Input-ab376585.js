import{i as re,j as P,cO as Se,bO as Pe,cJ as Fe,dk as un,g as k,h as t,aW as dn,b as x,e as _,x as i,aE as fn,aX as Re,t as fe,aM as hn,s as U,N as ne,bW as vn,A as pn,r as y,D as gn,bc as bn,d as A,aF as H,u as mn,k as $e,dl as xn,a$ as wn,bB as we,o as yn,cE as Cn,w as ye,z as zn,aG as _n,as as de,bJ as An,n as Sn,aL as Q,a_ as Pn,a7 as Fn,bK as Rn,b8 as $n,v as Ce,bj as ze,aK as C,bk as _e}from"./index-e9a0fbbf.js";import{u as Bn}from"./use-locale-c4bd8581.js";function En(r,a){return re(r,o=>{o!==void 0&&(a.value=o)}),P(()=>r.value===void 0?a.value:r.value)}var kn=/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,In=/^\w*$/;function Tn(r,a){if(Se(r))return!1;var o=typeof r;return o=="number"||o=="symbol"||o=="boolean"||r==null||Pe(r)?!0:In.test(r)||!kn.test(r)||a!=null&&r in Object(a)}var Mn="Expected a function";function ve(r,a){if(typeof r!="function"||a!=null&&typeof a!="function")throw new TypeError(Mn);var o=function(){var g=arguments,z=a?a.apply(this,g):g[0],h=o.cache;if(h.has(z))return h.get(z);var f=r.apply(this,g);return o.cache=h.set(z,f)||h,f};return o.cache=new(ve.Cache||Fe),o}ve.Cache=Fe;var Dn=500;function Ln(r){var a=ve(r,function(g){return o.size===Dn&&o.clear(),g}),o=a.cache;return a}var Wn=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,Vn=/\\(\\)?/g,On=Ln(function(r){var a=[];return r.charCodeAt(0)===46&&a.push(""),r.replace(Wn,function(o,g,z,h){a.push(z?h.replace(Vn,"$1"):g||o)}),a});const Nn=On;function Kn(r,a){return Se(r)?r:Tn(r,a)?[r]:Nn(un(r))}var Hn=1/0;function Un(r){if(typeof r=="string"||Pe(r))return r;var a=r+"";return a=="0"&&1/r==-Hn?"-0":a}function jn(r,a){a=Kn(a,r);for(var o=0,g=a.length;r!=null&&o<g;)r=r[Un(a[o++])];return o&&o==g?r:void 0}function lo(r,a,o){var g=r==null?void 0:jn(r,a);return g===void 0?o:g}const Gn=k({name:"Eye",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 0 0-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 0 0 0-17.47C428.89 172.28 347.8 112 255.66 112z",fill:"none",stroke:"currentColor","stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"32"}),t("circle",{cx:"256",cy:"256",r:"80",fill:"none",stroke:"currentColor","stroke-miterlimit":"10","stroke-width":"32"}))}}),Xn=k({name:"EyeOff",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M432 448a15.92 15.92 0 0 1-11.31-4.69l-352-352a16 16 0 0 1 22.62-22.62l352 352A16 16 0 0 1 432 448z",fill:"currentColor"}),t("path",{d:"M255.66 384c-41.49 0-81.5-12.28-118.92-36.5c-34.07-22-64.74-53.51-88.7-91v-.08c19.94-28.57 41.78-52.73 65.24-72.21a2 2 0 0 0 .14-2.94L93.5 161.38a2 2 0 0 0-2.71-.12c-24.92 21-48.05 46.76-69.08 76.92a31.92 31.92 0 0 0-.64 35.54c26.41 41.33 60.4 76.14 98.28 100.65C162 402 207.9 416 255.66 416a239.13 239.13 0 0 0 75.8-12.58a2 2 0 0 0 .77-3.31l-21.58-21.58a4 4 0 0 0-3.83-1a204.8 204.8 0 0 1-51.16 6.47z",fill:"currentColor"}),t("path",{d:"M490.84 238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349 110.55 302 96 255.66 96a227.34 227.34 0 0 0-74.89 12.83a2 2 0 0 0-.75 3.31l21.55 21.55a4 4 0 0 0 3.88 1a192.82 192.82 0 0 1 50.21-6.69c40.69 0 80.58 12.43 118.55 37c34.71 22.4 65.74 53.88 89.76 91a.13.13 0 0 1 0 .16a310.72 310.72 0 0 1-64.12 72.73a2 2 0 0 0-.15 2.95l19.9 19.89a2 2 0 0 0 2.7.13a343.49 343.49 0 0 0 68.64-78.48a32.2 32.2 0 0 0-.1-34.78z",fill:"currentColor"}),t("path",{d:"M256 160a95.88 95.88 0 0 0-21.37 2.4a2 2 0 0 0-1 3.38l112.59 112.56a2 2 0 0 0 3.38-1A96 96 0 0 0 256 160z",fill:"currentColor"}),t("path",{d:"M165.78 233.66a2 2 0 0 0-3.38 1a96 96 0 0 0 115 115a2 2 0 0 0 1-3.38z",fill:"currentColor"}))}}),Yn=k({name:"ChevronDown",render(){return t("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M3.14645 5.64645C3.34171 5.45118 3.65829 5.45118 3.85355 5.64645L8 9.79289L12.1464 5.64645C12.3417 5.45118 12.6583 5.45118 12.8536 5.64645C13.0488 5.84171 13.0488 6.15829 12.8536 6.35355L8.35355 10.8536C8.15829 11.0488 7.84171 11.0488 7.64645 10.8536L3.14645 6.35355C2.95118 6.15829 2.95118 5.84171 3.14645 5.64645Z",fill:"currentColor"}))}}),Zn=dn("clear",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M8,2 C11.3137085,2 14,4.6862915 14,8 C14,11.3137085 11.3137085,14 8,14 C4.6862915,14 2,11.3137085 2,8 C2,4.6862915 4.6862915,2 8,2 Z M6.5343055,5.83859116 C6.33943736,5.70359511 6.07001296,5.72288026 5.89644661,5.89644661 L5.89644661,5.89644661 L5.83859116,5.9656945 C5.70359511,6.16056264 5.72288026,6.42998704 5.89644661,6.60355339 L5.89644661,6.60355339 L7.293,8 L5.89644661,9.39644661 L5.83859116,9.4656945 C5.70359511,9.66056264 5.72288026,9.92998704 5.89644661,10.1035534 L5.89644661,10.1035534 L5.9656945,10.1614088 C6.16056264,10.2964049 6.42998704,10.2771197 6.60355339,10.1035534 L6.60355339,10.1035534 L8,8.707 L9.39644661,10.1035534 L9.4656945,10.1614088 C9.66056264,10.2964049 9.92998704,10.2771197 10.1035534,10.1035534 L10.1035534,10.1035534 L10.1614088,10.0343055 C10.2964049,9.83943736 10.2771197,9.57001296 10.1035534,9.39644661 L10.1035534,9.39644661 L8.707,8 L10.1035534,6.60355339 L10.1614088,6.5343055 C10.2964049,6.33943736 10.2771197,6.07001296 10.1035534,5.89644661 L10.1035534,5.89644661 L10.0343055,5.83859116 C9.83943736,5.70359511 9.57001296,5.72288026 9.39644661,5.89644661 L9.39644661,5.89644661 L8,7.293 L6.60355339,5.89644661 Z"}))))),qn=x("base-clear",`
 flex-shrink: 0;
 height: 1em;
 width: 1em;
 position: relative;
`,[_(">",[i("clear",`
 font-size: var(--n-clear-size);
 height: 1em;
 width: 1em;
 cursor: pointer;
 color: var(--n-clear-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 `,[_("&:hover",`
 color: var(--n-clear-color-hover)!important;
 `),_("&:active",`
 color: var(--n-clear-color-pressed)!important;
 `)]),i("placeholder",`
 display: flex;
 `),i("clear, placeholder",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[fn({originalTransform:"translateX(-50%) translateY(-50%)",left:"50%",top:"50%"})])])]),he=k({name:"BaseClear",props:{clsPrefix:{type:String,required:!0},show:Boolean,onClear:Function},setup(r){return Re("-base-clear",qn,fe(r,"clsPrefix")),{handleMouseDown(a){a.preventDefault()}}},render(){const{clsPrefix:r}=this;return t("div",{class:`${r}-base-clear`},t(hn,null,{default:()=>{var a,o;return this.show?t("div",{key:"dismiss",class:`${r}-base-clear__clear`,onClick:this.onClear,onMousedown:this.handleMouseDown,"data-clear":!0},U(this.$slots.icon,()=>[t(ne,{clsPrefix:r},{default:()=>t(Zn,null)})])):t("div",{key:"icon",class:`${r}-base-clear__placeholder`},(o=(a=this.$slots).placeholder)===null||o===void 0?void 0:o.call(a))}}))}}),Jn=k({name:"InternalSelectionSuffix",props:{clsPrefix:{type:String,required:!0},showArrow:{type:Boolean,default:void 0},showClear:{type:Boolean,default:void 0},loading:{type:Boolean,default:!1},onClear:Function},setup(r,{slots:a}){return()=>{const{clsPrefix:o}=r;return t(vn,{clsPrefix:o,class:`${o}-base-suffix`,strokeWidth:24,scale:.85,show:r.loading},{default:()=>r.showArrow?t(he,{clsPrefix:o,show:r.showClear,onClear:r.onClear},{placeholder:()=>t(ne,{clsPrefix:o,class:`${o}-base-suffix__arrow`},{default:()=>U(a.default,()=>[t(Yn,null)])})}):null})}}}),Be=pn("n-input");function Qn(r){let a=0;for(const o of r)a++;return a}function ee(r){return r===""||r==null}function eo(r){const a=y(null);function o(){const{value:h}=r;if(!(h!=null&&h.focus)){z();return}const{selectionStart:f,selectionEnd:c,value:d}=h;if(f==null||c==null){z();return}a.value={start:f,end:c,beforeText:d.slice(0,f),afterText:d.slice(c)}}function g(){var h;const{value:f}=a,{value:c}=r;if(!f||!c)return;const{value:d}=c,{start:u,beforeText:s,afterText:m}=f;let w=d.length;if(d.endsWith(m))w=d.length-m.length;else if(d.startsWith(s))w=s.length;else{const I=s[u-1],S=d.indexOf(I,u-1);S!==-1&&(w=S+1)}(h=c.setSelectionRange)===null||h===void 0||h.call(c,w,w)}function z(){a.value=null}return re(r,z),{recordCursor:o,restoreCursor:g}}const Ae=k({name:"InputWordCount",setup(r,{slots:a}){const{mergedValueRef:o,maxlengthRef:g,mergedClsPrefixRef:z,countGraphemesRef:h}=gn(Be),f=P(()=>{const{value:c}=o;return c===null||Array.isArray(c)?0:(h.value||Qn)(c)});return()=>{const{value:c}=g,{value:d}=o;return t("span",{class:`${z.value}-input-word-count`},bn(a.default,{value:d===null||Array.isArray(d)?"":d},()=>[c===void 0?f.value:`${f.value} / ${c}`]))}}}),ro=x("input",`
 max-width: 100%;
 cursor: text;
 line-height: 1.5;
 z-index: auto;
 outline: none;
 box-sizing: border-box;
 position: relative;
 display: inline-flex;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color .3s var(--n-bezier);
 font-size: var(--n-font-size);
 --n-padding-vertical: calc((var(--n-height) - 1.5 * var(--n-font-size)) / 2);
`,[i("input, textarea",`
 overflow: hidden;
 flex-grow: 1;
 position: relative;
 `),i("input-el, textarea-el, input-mirror, textarea-mirror, separator, placeholder",`
 box-sizing: border-box;
 font-size: inherit;
 line-height: 1.5;
 font-family: inherit;
 border: none;
 outline: none;
 background-color: #0000;
 text-align: inherit;
 transition:
 -webkit-text-fill-color .3s var(--n-bezier),
 caret-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier);
 `),i("input-el, textarea-el",`
 -webkit-appearance: none;
 scrollbar-width: none;
 width: 100%;
 min-width: 0;
 text-decoration-color: var(--n-text-decoration-color);
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 background-color: transparent;
 `,[_("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",`
 width: 0;
 height: 0;
 display: none;
 `),_("&::placeholder",`
 color: #0000;
 -webkit-text-fill-color: transparent !important;
 `),_("&:-webkit-autofill ~",[i("placeholder","display: none;")])]),A("round",[H("textarea","border-radius: calc(var(--n-height) / 2);")]),i("placeholder",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 overflow: hidden;
 color: var(--n-placeholder-color);
 `,[_("span",`
 width: 100%;
 display: inline-block;
 `)]),A("textarea",[i("placeholder","overflow: visible;")]),H("autosize","width: 100%;"),A("autosize",[i("textarea-el, input-el",`
 position: absolute;
 top: 0;
 left: 0;
 height: 100%;
 `)]),x("input-wrapper",`
 overflow: hidden;
 display: inline-flex;
 flex-grow: 1;
 position: relative;
 padding-left: var(--n-padding-left);
 padding-right: var(--n-padding-right);
 `),i("input-mirror",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre;
 pointer-events: none;
 `),i("input-el",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 `,[_("&[type=password]::-ms-reveal","display: none;"),_("+",[i("placeholder",`
 display: flex;
 align-items: center; 
 `)])]),H("textarea",[i("placeholder","white-space: nowrap;")]),i("eye",`
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `),A("textarea","width: 100%;",[x("input-word-count",`
 position: absolute;
 right: var(--n-padding-right);
 bottom: var(--n-padding-vertical);
 `),A("resizable",[x("input-wrapper",`
 resize: vertical;
 min-height: var(--n-height);
 `)]),i("textarea-el, textarea-mirror, placeholder",`
 height: 100%;
 padding-left: 0;
 padding-right: 0;
 padding-top: var(--n-padding-vertical);
 padding-bottom: var(--n-padding-vertical);
 word-break: break-word;
 display: inline-block;
 vertical-align: bottom;
 box-sizing: border-box;
 line-height: var(--n-line-height-textarea);
 margin: 0;
 resize: none;
 white-space: pre-wrap;
 scroll-padding-block-end: var(--n-padding-vertical);
 `),i("textarea-mirror",`
 width: 100%;
 pointer-events: none;
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre-wrap;
 overflow-wrap: break-word;
 `)]),A("pair",[i("input-el, placeholder","text-align: center;"),i("separator",`
 display: flex;
 align-items: center;
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 white-space: nowrap;
 `,[x("icon",`
 color: var(--n-icon-color);
 `),x("base-icon",`
 color: var(--n-icon-color);
 `)])]),A("disabled",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[i("border","border: var(--n-border-disabled);"),i("input-el, textarea-el",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 text-decoration-color: var(--n-text-color-disabled);
 `),i("placeholder","color: var(--n-placeholder-color-disabled);"),i("separator","color: var(--n-text-color-disabled);",[x("icon",`
 color: var(--n-icon-color-disabled);
 `),x("base-icon",`
 color: var(--n-icon-color-disabled);
 `)]),x("input-word-count",`
 color: var(--n-count-text-color-disabled);
 `),i("suffix, prefix","color: var(--n-text-color-disabled);",[x("icon",`
 color: var(--n-icon-color-disabled);
 `),x("internal-icon",`
 color: var(--n-icon-color-disabled);
 `)])]),H("disabled",[i("eye",`
 color: var(--n-icon-color);
 cursor: pointer;
 `,[_("&:hover",`
 color: var(--n-icon-color-hover);
 `),_("&:active",`
 color: var(--n-icon-color-pressed);
 `)]),_("&:hover",[i("state-border","border: var(--n-border-hover);")]),A("focus","background-color: var(--n-color-focus);",[i("state-border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),i("border, state-border",`
 box-sizing: border-box;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: inherit;
 border: var(--n-border);
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),i("state-border",`
 border-color: #0000;
 z-index: 1;
 `),i("prefix","margin-right: 4px;"),i("suffix",`
 margin-left: 4px;
 `),i("suffix, prefix",`
 transition: color .3s var(--n-bezier);
 flex-wrap: nowrap;
 flex-shrink: 0;
 line-height: var(--n-height);
 white-space: nowrap;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 color: var(--n-suffix-text-color);
 `,[x("base-loading",`
 font-size: var(--n-icon-size);
 margin: 0 2px;
 color: var(--n-loading-color);
 `),x("base-clear",`
 font-size: var(--n-icon-size);
 `,[i("placeholder",[x("base-icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)])]),_(">",[x("icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)]),x("base-icon",`
 font-size: var(--n-icon-size);
 `)]),x("input-word-count",`
 pointer-events: none;
 line-height: 1.5;
 font-size: .85em;
 color: var(--n-count-text-color);
 transition: color .3s var(--n-bezier);
 margin-left: 4px;
 font-variant: tabular-nums;
 `),["warning","error"].map(r=>A(`${r}-status`,[H("disabled",[x("base-loading",`
 color: var(--n-loading-color-${r})
 `),i("input-el, textarea-el",`
 caret-color: var(--n-caret-color-${r});
 `),i("state-border",`
 border: var(--n-border-${r});
 `),_("&:hover",[i("state-border",`
 border: var(--n-border-hover-${r});
 `)]),_("&:focus",`
 background-color: var(--n-color-focus-${r});
 `,[i("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)]),A("focus",`
 background-color: var(--n-color-focus-${r});
 `,[i("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)])])]))]),no=x("input",[A("disabled",[i("input-el, textarea-el",`
 -webkit-text-fill-color: var(--n-text-color-disabled);
 `)])]),oo=Object.assign(Object.assign({},$e.props),{bordered:{type:Boolean,default:void 0},type:{type:String,default:"text"},placeholder:[Array,String],defaultValue:{type:[String,Array],default:null},value:[String,Array],disabled:{type:Boolean,default:void 0},size:String,rows:{type:[Number,String],default:3},round:Boolean,minlength:[String,Number],maxlength:[String,Number],clearable:Boolean,autosize:{type:[Boolean,Object],default:!1},pair:Boolean,separator:String,readonly:{type:[String,Boolean],default:!1},passivelyActivated:Boolean,showPasswordOn:String,stateful:{type:Boolean,default:!0},autofocus:Boolean,inputProps:Object,resizable:{type:Boolean,default:!0},showCount:Boolean,loading:{type:Boolean,default:void 0},allowInput:Function,renderCount:Function,onMousedown:Function,onKeydown:Function,onKeyup:[Function,Array],onInput:[Function,Array],onFocus:[Function,Array],onBlur:[Function,Array],onClick:[Function,Array],onChange:[Function,Array],onClear:[Function,Array],countGraphemes:Function,status:String,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],textDecoration:[String,Array],attrSize:{type:Number,default:20},onInputBlur:[Function,Array],onInputFocus:[Function,Array],onDeactivate:[Function,Array],onActivate:[Function,Array],onWrapperFocus:[Function,Array],onWrapperBlur:[Function,Array],internalDeactivateOnEnter:Boolean,internalForceFocus:Boolean,internalLoadingBeforeSuffix:{type:Boolean,default:!0},showPasswordToggle:Boolean}),io=k({name:"Input",props:oo,setup(r){const{mergedClsPrefixRef:a,mergedBorderedRef:o,inlineThemeDisabled:g,mergedRtlRef:z}=mn(r),h=$e("Input","-input",ro,$n,r,a);xn&&Re("-input-safari",no,a);const f=y(null),c=y(null),d=y(null),u=y(null),s=y(null),m=y(null),w=y(null),I=eo(w),S=y(null),{localeRef:Ee}=Bn("Input"),j=y(r.defaultValue),ke=fe(r,"value"),F=En(ke,j),L=wn(r),{mergedSizeRef:oe,mergedDisabledRef:T,mergedStatusRef:Ie}=L,M=y(!1),W=y(!1),R=y(!1),V=y(!1);let te=null;const ae=P(()=>{const{placeholder:e,pair:n}=r;return n?Array.isArray(e)?e:e===void 0?["",""]:[e,e]:e===void 0?[Ee.value.placeholder]:[e]}),Te=P(()=>{const{value:e}=R,{value:n}=F,{value:l}=ae;return!e&&(ee(n)||Array.isArray(n)&&ee(n[0]))&&l[0]}),Me=P(()=>{const{value:e}=R,{value:n}=F,{value:l}=ae;return!e&&l[1]&&(ee(n)||Array.isArray(n)&&ee(n[1]))}),le=we(()=>r.internalForceFocus||M.value),De=we(()=>{if(T.value||r.readonly||!r.clearable||!le.value&&!W.value)return!1;const{value:e}=F,{value:n}=le;return r.pair?!!(Array.isArray(e)&&(e[0]||e[1]))&&(W.value||n):!!e&&(W.value||n)}),ie=P(()=>{const{showPasswordOn:e}=r;if(e)return e;if(r.showPasswordToggle)return"click"}),O=y(!1),Le=P(()=>{const{textDecoration:e}=r;return e?Array.isArray(e)?e.map(n=>({textDecoration:n})):[{textDecoration:e}]:["",""]}),pe=y(void 0),We=()=>{var e,n;if(r.type==="textarea"){const{autosize:l}=r;if(l&&(pe.value=(n=(e=S.value)===null||e===void 0?void 0:e.$el)===null||n===void 0?void 0:n.offsetWidth),!c.value||typeof l=="boolean")return;const{paddingTop:p,paddingBottom:b,lineHeight:v}=window.getComputedStyle(c.value),$=Number(p.slice(0,-2)),B=Number(b.slice(0,-2)),E=Number(v.slice(0,-2)),{value:N}=d;if(!N)return;if(l.minRows){const K=Math.max(l.minRows,1),ue=`${$+B+E*K}px`;N.style.minHeight=ue}if(l.maxRows){const K=`${$+B+E*l.maxRows}px`;N.style.maxHeight=K}}},Ve=P(()=>{const{maxlength:e}=r;return e===void 0?void 0:Number(e)});yn(()=>{const{value:e}=F;Array.isArray(e)||ce(e)});const Oe=Cn().proxy;function G(e,n){const{onUpdateValue:l,"onUpdate:value":p,onInput:b}=r,{nTriggerFormInput:v}=L;l&&C(l,e,n),p&&C(p,e,n),b&&C(b,e,n),j.value=e,v()}function X(e,n){const{onChange:l}=r,{nTriggerFormChange:p}=L;l&&C(l,e,n),j.value=e,p()}function Ne(e){const{onBlur:n}=r,{nTriggerFormBlur:l}=L;n&&C(n,e),l()}function Ke(e){const{onFocus:n}=r,{nTriggerFormFocus:l}=L;n&&C(n,e),l()}function He(e){const{onClear:n}=r;n&&C(n,e)}function Ue(e){const{onInputBlur:n}=r;n&&C(n,e)}function je(e){const{onInputFocus:n}=r;n&&C(n,e)}function Ge(){const{onDeactivate:e}=r;e&&C(e)}function Xe(){const{onActivate:e}=r;e&&C(e)}function Ye(e){const{onClick:n}=r;n&&C(n,e)}function Ze(e){const{onWrapperFocus:n}=r;n&&C(n,e)}function qe(e){const{onWrapperBlur:n}=r;n&&C(n,e)}function Je(){R.value=!0}function Qe(e){R.value=!1,e.target===m.value?Y(e,1):Y(e,0)}function Y(e,n=0,l="input"){const p=e.target.value;if(ce(p),e instanceof InputEvent&&!e.isComposing&&(R.value=!1),r.type==="textarea"){const{value:v}=S;v&&v.syncUnifiedContainer()}if(te=p,R.value)return;I.recordCursor();const b=er(p);if(b)if(!r.pair)l==="input"?G(p,{source:n}):X(p,{source:n});else{let{value:v}=F;Array.isArray(v)?v=[v[0],v[1]]:v=["",""],v[n]=p,l==="input"?G(v,{source:n}):X(v,{source:n})}Oe.$forceUpdate(),b||Ce(I.restoreCursor)}function er(e){const{countGraphemes:n,maxlength:l,minlength:p}=r;if(n){let v;if(l!==void 0&&(v===void 0&&(v=n(e)),v>Number(l))||p!==void 0&&(v===void 0&&(v=n(e)),v<Number(l)))return!1}const{allowInput:b}=r;return typeof b=="function"?b(e):!0}function rr(e){Ue(e),e.relatedTarget===f.value&&Ge(),e.relatedTarget!==null&&(e.relatedTarget===s.value||e.relatedTarget===m.value||e.relatedTarget===c.value)||(V.value=!1),Z(e,"blur"),w.value=null}function nr(e,n){je(e),M.value=!0,V.value=!0,Xe(),Z(e,"focus"),n===0?w.value=s.value:n===1?w.value=m.value:n===2&&(w.value=c.value)}function or(e){r.passivelyActivated&&(qe(e),Z(e,"blur"))}function tr(e){r.passivelyActivated&&(M.value=!0,Ze(e),Z(e,"focus"))}function Z(e,n){e.relatedTarget!==null&&(e.relatedTarget===s.value||e.relatedTarget===m.value||e.relatedTarget===c.value||e.relatedTarget===f.value)||(n==="focus"?(Ke(e),M.value=!0):n==="blur"&&(Ne(e),M.value=!1))}function ar(e,n){Y(e,n,"change")}function lr(e){Ye(e)}function ir(e){He(e),ge()}function ge(){r.pair?(G(["",""],{source:"clear"}),X(["",""],{source:"clear"})):(G("",{source:"clear"}),X("",{source:"clear"}))}function sr(e){const{onMousedown:n}=r;n&&n(e);const{tagName:l}=e.target;if(l!=="INPUT"&&l!=="TEXTAREA"){if(r.resizable){const{value:p}=f;if(p){const{left:b,top:v,width:$,height:B}=p.getBoundingClientRect(),E=14;if(b+$-E<e.clientX&&e.clientX<b+$&&v+B-E<e.clientY&&e.clientY<v+B)return}}e.preventDefault(),M.value||be()}}function cr(){var e;W.value=!0,r.type==="textarea"&&((e=S.value)===null||e===void 0||e.handleMouseEnterWrapper())}function ur(){var e;W.value=!1,r.type==="textarea"&&((e=S.value)===null||e===void 0||e.handleMouseLeaveWrapper())}function dr(){T.value||ie.value==="click"&&(O.value=!O.value)}function fr(e){if(T.value)return;e.preventDefault();const n=p=>{p.preventDefault(),_e("mouseup",document,n)};if(ze("mouseup",document,n),ie.value!=="mousedown")return;O.value=!0;const l=()=>{O.value=!1,_e("mouseup",document,l)};ze("mouseup",document,l)}function hr(e){r.onKeyup&&C(r.onKeyup,e)}function vr(e){switch(r.onKeydown&&C(r.onKeydown,e),e.key){case"Escape":se();break;case"Enter":pr(e);break}}function pr(e){var n,l;if(r.passivelyActivated){const{value:p}=V;if(p){r.internalDeactivateOnEnter&&se();return}e.preventDefault(),r.type==="textarea"?(n=c.value)===null||n===void 0||n.focus():(l=s.value)===null||l===void 0||l.focus()}}function se(){r.passivelyActivated&&(V.value=!1,Ce(()=>{var e;(e=f.value)===null||e===void 0||e.focus()}))}function be(){var e,n,l;T.value||(r.passivelyActivated?(e=f.value)===null||e===void 0||e.focus():((n=c.value)===null||n===void 0||n.focus(),(l=s.value)===null||l===void 0||l.focus()))}function gr(){var e;!((e=f.value)===null||e===void 0)&&e.contains(document.activeElement)&&document.activeElement.blur()}function br(){var e,n;(e=c.value)===null||e===void 0||e.select(),(n=s.value)===null||n===void 0||n.select()}function mr(){T.value||(c.value?c.value.focus():s.value&&s.value.focus())}function xr(){const{value:e}=f;e!=null&&e.contains(document.activeElement)&&e!==document.activeElement&&se()}function wr(e){if(r.type==="textarea"){const{value:n}=c;n==null||n.scrollTo(e)}else{const{value:n}=s;n==null||n.scrollTo(e)}}function ce(e){const{type:n,pair:l,autosize:p}=r;if(!l&&p)if(n==="textarea"){const{value:b}=d;b&&(b.textContent=(e??"")+`\r
`)}else{const{value:b}=u;b&&(e?b.textContent=e:b.innerHTML="&nbsp;")}}function yr(){We()}const me=y({top:"0"});function Cr(e){var n;const{scrollTop:l}=e.target;me.value.top=`${-l}px`,(n=S.value)===null||n===void 0||n.syncUnifiedContainer()}let q=null;ye(()=>{const{autosize:e,type:n}=r;e&&n==="textarea"?q=re(F,l=>{!Array.isArray(l)&&l!==te&&ce(l)}):q==null||q()});let J=null;ye(()=>{r.type==="textarea"?J=re(F,e=>{var n;!Array.isArray(e)&&e!==te&&((n=S.value)===null||n===void 0||n.syncUnifiedContainer())}):J==null||J()}),zn(Be,{mergedValueRef:F,maxlengthRef:Ve,mergedClsPrefixRef:a,countGraphemesRef:fe(r,"countGraphemes")});const zr={wrapperElRef:f,inputElRef:s,textareaElRef:c,isCompositing:R,clear:ge,focus:be,blur:gr,select:br,deactivate:xr,activate:mr,scrollTo:wr},_r=_n("Input",z,a),xe=P(()=>{const{value:e}=oe,{common:{cubicBezierEaseInOut:n},self:{color:l,borderRadius:p,textColor:b,caretColor:v,caretColorError:$,caretColorWarning:B,textDecorationColor:E,border:N,borderDisabled:K,borderHover:ue,borderFocus:Ar,placeholderColor:Sr,placeholderColorDisabled:Pr,lineHeightTextarea:Fr,colorDisabled:Rr,colorFocus:$r,textColorDisabled:Br,boxShadowFocus:Er,iconSize:kr,colorFocusWarning:Ir,boxShadowFocusWarning:Tr,borderWarning:Mr,borderFocusWarning:Dr,borderHoverWarning:Lr,colorFocusError:Wr,boxShadowFocusError:Vr,borderError:Or,borderFocusError:Nr,borderHoverError:Kr,clearSize:Hr,clearColor:Ur,clearColorHover:jr,clearColorPressed:Gr,iconColor:Xr,iconColorDisabled:Yr,suffixTextColor:Zr,countTextColor:qr,countTextColorDisabled:Jr,iconColorHover:Qr,iconColorPressed:en,loadingColor:rn,loadingColorError:nn,loadingColorWarning:on,[de("padding",e)]:tn,[de("fontSize",e)]:an,[de("height",e)]:ln}}=h.value,{left:sn,right:cn}=An(tn);return{"--n-bezier":n,"--n-count-text-color":qr,"--n-count-text-color-disabled":Jr,"--n-color":l,"--n-font-size":an,"--n-border-radius":p,"--n-height":ln,"--n-padding-left":sn,"--n-padding-right":cn,"--n-text-color":b,"--n-caret-color":v,"--n-text-decoration-color":E,"--n-border":N,"--n-border-disabled":K,"--n-border-hover":ue,"--n-border-focus":Ar,"--n-placeholder-color":Sr,"--n-placeholder-color-disabled":Pr,"--n-icon-size":kr,"--n-line-height-textarea":Fr,"--n-color-disabled":Rr,"--n-color-focus":$r,"--n-text-color-disabled":Br,"--n-box-shadow-focus":Er,"--n-loading-color":rn,"--n-caret-color-warning":B,"--n-color-focus-warning":Ir,"--n-box-shadow-focus-warning":Tr,"--n-border-warning":Mr,"--n-border-focus-warning":Dr,"--n-border-hover-warning":Lr,"--n-loading-color-warning":on,"--n-caret-color-error":$,"--n-color-focus-error":Wr,"--n-box-shadow-focus-error":Vr,"--n-border-error":Or,"--n-border-focus-error":Nr,"--n-border-hover-error":Kr,"--n-loading-color-error":nn,"--n-clear-color":Ur,"--n-clear-size":Hr,"--n-clear-color-hover":jr,"--n-clear-color-pressed":Gr,"--n-icon-color":Xr,"--n-icon-color-hover":Qr,"--n-icon-color-pressed":en,"--n-icon-color-disabled":Yr,"--n-suffix-text-color":Zr}}),D=g?Sn("input",P(()=>{const{value:e}=oe;return e[0]}),xe,r):void 0;return Object.assign(Object.assign({},zr),{wrapperElRef:f,inputElRef:s,inputMirrorElRef:u,inputEl2Ref:m,textareaElRef:c,textareaMirrorElRef:d,textareaScrollbarInstRef:S,rtlEnabled:_r,uncontrolledValue:j,mergedValue:F,passwordVisible:O,mergedPlaceholder:ae,showPlaceholder1:Te,showPlaceholder2:Me,mergedFocus:le,isComposing:R,activated:V,showClearButton:De,mergedSize:oe,mergedDisabled:T,textDecorationStyle:Le,mergedClsPrefix:a,mergedBordered:o,mergedShowPasswordOn:ie,placeholderStyle:me,mergedStatus:Ie,textAreaScrollContainerWidth:pe,handleTextAreaScroll:Cr,handleCompositionStart:Je,handleCompositionEnd:Qe,handleInput:Y,handleInputBlur:rr,handleInputFocus:nr,handleWrapperBlur:or,handleWrapperFocus:tr,handleMouseEnter:cr,handleMouseLeave:ur,handleMouseDown:sr,handleChange:ar,handleClick:lr,handleClear:ir,handlePasswordToggleClick:dr,handlePasswordToggleMousedown:fr,handleWrapperKeydown:vr,handleWrapperKeyup:hr,handleTextAreaMirrorResize:yr,getTextareaScrollContainer:()=>c.value,mergedTheme:h,cssVars:g?void 0:xe,themeClass:D==null?void 0:D.themeClass,onRender:D==null?void 0:D.onRender})},render(){var r,a;const{mergedClsPrefix:o,mergedStatus:g,themeClass:z,type:h,countGraphemes:f,onRender:c}=this,d=this.$slots;return c==null||c(),t("div",{ref:"wrapperElRef",class:[`${o}-input`,z,g&&`${o}-input--${g}-status`,{[`${o}-input--rtl`]:this.rtlEnabled,[`${o}-input--disabled`]:this.mergedDisabled,[`${o}-input--textarea`]:h==="textarea",[`${o}-input--resizable`]:this.resizable&&!this.autosize,[`${o}-input--autosize`]:this.autosize,[`${o}-input--round`]:this.round&&h!=="textarea",[`${o}-input--pair`]:this.pair,[`${o}-input--focus`]:this.mergedFocus,[`${o}-input--stateful`]:this.stateful}],style:this.cssVars,tabindex:!this.mergedDisabled&&this.passivelyActivated&&!this.activated?0:void 0,onFocus:this.handleWrapperFocus,onBlur:this.handleWrapperBlur,onClick:this.handleClick,onMousedown:this.handleMouseDown,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd,onKeyup:this.handleWrapperKeyup,onKeydown:this.handleWrapperKeydown},t("div",{class:`${o}-input-wrapper`},Q(d.prefix,u=>u&&t("div",{class:`${o}-input__prefix`},u)),h==="textarea"?t(Pn,{ref:"textareaScrollbarInstRef",class:`${o}-input__textarea`,container:this.getTextareaScrollContainer,triggerDisplayManually:!0,useUnifiedContainer:!0,internalHoistYRail:!0},{default:()=>{var u,s;const{textAreaScrollContainerWidth:m}=this,w={width:this.autosize&&m&&`${m}px`};return t(Fn,null,t("textarea",Object.assign({},this.inputProps,{ref:"textareaElRef",class:[`${o}-input__textarea-el`,(u=this.inputProps)===null||u===void 0?void 0:u.class],autofocus:this.autofocus,rows:Number(this.rows),placeholder:this.placeholder,value:this.mergedValue,disabled:this.mergedDisabled,maxlength:f?void 0:this.maxlength,minlength:f?void 0:this.minlength,readonly:this.readonly,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,style:[this.textDecorationStyle[0],(s=this.inputProps)===null||s===void 0?void 0:s.style,w],onBlur:this.handleInputBlur,onFocus:I=>{this.handleInputFocus(I,2)},onInput:this.handleInput,onChange:this.handleChange,onScroll:this.handleTextAreaScroll})),this.showPlaceholder1?t("div",{class:`${o}-input__placeholder`,style:[this.placeholderStyle,w],key:"placeholder"},this.mergedPlaceholder[0]):null,this.autosize?t(Rn,{onResize:this.handleTextAreaMirrorResize},{default:()=>t("div",{ref:"textareaMirrorElRef",class:`${o}-input__textarea-mirror`,key:"mirror"})}):null)}}):t("div",{class:`${o}-input__input`},t("input",Object.assign({type:h==="password"&&this.mergedShowPasswordOn&&this.passwordVisible?"text":h},this.inputProps,{ref:"inputElRef",class:[`${o}-input__input-el`,(r=this.inputProps)===null||r===void 0?void 0:r.class],style:[this.textDecorationStyle[0],(a=this.inputProps)===null||a===void 0?void 0:a.style],tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[0],disabled:this.mergedDisabled,maxlength:f?void 0:this.maxlength,minlength:f?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[0]:this.mergedValue,readonly:this.readonly,autofocus:this.autofocus,size:this.attrSize,onBlur:this.handleInputBlur,onFocus:u=>{this.handleInputFocus(u,0)},onInput:u=>{this.handleInput(u,0)},onChange:u=>{this.handleChange(u,0)}})),this.showPlaceholder1?t("div",{class:`${o}-input__placeholder`},t("span",null,this.mergedPlaceholder[0])):null,this.autosize?t("div",{class:`${o}-input__input-mirror`,key:"mirror",ref:"inputMirrorElRef"}," "):null),!this.pair&&Q(d.suffix,u=>u||this.clearable||this.showCount||this.mergedShowPasswordOn||this.loading!==void 0?t("div",{class:`${o}-input__suffix`},[Q(d["clear-icon-placeholder"],s=>(this.clearable||s)&&t(he,{clsPrefix:o,show:this.showClearButton,onClear:this.handleClear},{placeholder:()=>s,icon:()=>{var m,w;return(w=(m=this.$slots)["clear-icon"])===null||w===void 0?void 0:w.call(m)}})),this.internalLoadingBeforeSuffix?null:u,this.loading!==void 0?t(Jn,{clsPrefix:o,loading:this.loading,showArrow:!1,showClear:!1,style:this.cssVars}):null,this.internalLoadingBeforeSuffix?u:null,this.showCount&&this.type!=="textarea"?t(Ae,null,{default:s=>{var m;return(m=d.count)===null||m===void 0?void 0:m.call(d,s)}}):null,this.mergedShowPasswordOn&&this.type==="password"?t("div",{class:`${o}-input__eye`,onMousedown:this.handlePasswordToggleMousedown,onClick:this.handlePasswordToggleClick},this.passwordVisible?U(d["password-visible-icon"],()=>[t(ne,{clsPrefix:o},{default:()=>t(Gn,null)})]):U(d["password-invisible-icon"],()=>[t(ne,{clsPrefix:o},{default:()=>t(Xn,null)})])):null]):null)),this.pair?t("span",{class:`${o}-input__separator`},U(d.separator,()=>[this.separator])):null,this.pair?t("div",{class:`${o}-input-wrapper`},t("div",{class:`${o}-input__input`},t("input",{ref:"inputEl2Ref",type:this.type,class:`${o}-input__input-el`,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[1],disabled:this.mergedDisabled,maxlength:f?void 0:this.maxlength,minlength:f?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[1]:void 0,readonly:this.readonly,style:this.textDecorationStyle[1],onBlur:this.handleInputBlur,onFocus:u=>{this.handleInputFocus(u,1)},onInput:u=>{this.handleInput(u,1)},onChange:u=>{this.handleChange(u,1)}}),this.showPlaceholder2?t("div",{class:`${o}-input__placeholder`},t("span",null,this.mergedPlaceholder[1])):null),Q(d.suffix,u=>(this.clearable||u)&&t("div",{class:`${o}-input__suffix`},[this.clearable&&t(he,{clsPrefix:o,show:this.showClearButton,onClear:this.handleClear},{icon:()=>{var s;return(s=d["clear-icon"])===null||s===void 0?void 0:s.call(d)},placeholder:()=>{var s;return(s=d["clear-icon-placeholder"])===null||s===void 0?void 0:s.call(d)}}),u]))):null,this.mergedBordered?t("div",{class:`${o}-input__border`}):null,this.mergedBordered?t("div",{class:`${o}-input__state-border`}):null,this.showCount&&h==="textarea"?t(Ae,null,{default:u=>{var s;const{renderCount:m}=this;return m?m(u):(s=d.count)===null||s===void 0?void 0:s.call(d,u)}}):null)}});export{Yn as C,Jn as N,io as _,jn as b,Kn as c,lo as g,Tn as i,Un as t,En as u};
