import{bl as t}from"./index-e9a0fbbf.js";function c(e){return t.post("/v1/cl/device/qyLock/getGylockList",e)}function r(e){return t.post("/v1/cl/device/qyLock/getGylockLog",e)}export{c as a,r as f};
