import{b as i,d as y,e as m,x as z,aE as C,aF as Q,g as $,u as F,aG as X,k as E,z as Y,h as s,aH as Z,A as ee,aI as te,D as se,aJ as ne,j as b,as as d,n as ie,aK as R,aL as T,s as w,aM as re,N,aN as oe,r as I,o as ae,aO as B,m as ce,J as P,K as j,$ as S,a0 as f,M as h,U as le,ax as de,ay as pe,_ as ue}from"./index-e9a0fbbf.js";import{g as fe}from"./get-slot-1efb97e5.js";import{F as he}from"./Checkmark-49c0d9bf.js";const ve=i("steps",`
 width: 100%;
 display: flex;
`,[i("step",`
 position: relative;
 display: flex;
 flex: 1;
 `,[y("disabled","cursor: not-allowed"),y("clickable",`
 cursor: pointer;
 `),m("&:last-child",[i("step-splitor","display: none;")])]),i("step-splitor",`
 background-color: var(--n-splitor-color);
 margin-top: calc(var(--n-step-header-font-size) / 2);
 height: 1px;
 flex: 1;
 align-self: flex-start;
 margin-left: 12px;
 margin-right: 12px;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),i("step-content","flex: 1;",[i("step-content-header",`
 color: var(--n-header-text-color);
 margin-top: calc(var(--n-indicator-size) / 2 - var(--n-step-header-font-size) / 2);
 line-height: var(--n-step-header-font-size);
 font-size: var(--n-step-header-font-size);
 position: relative;
 display: flex;
 font-weight: var(--n-step-header-font-weight);
 margin-left: 9px;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[z("title",`
 white-space: nowrap;
 flex: 0;
 `)]),z("description",`
 color: var(--n-description-text-color);
 margin-top: 12px;
 margin-left: 9px;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),i("step-indicator",`
 background-color: var(--n-indicator-color);
 box-shadow: 0 0 0 1px var(--n-indicator-border-color);
 height: var(--n-indicator-size);
 width: var(--n-indicator-size);
 border-radius: 50%;
 display: flex;
 align-items: center;
 justify-content: center;
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 `,[i("step-indicator-slot",`
 position: relative;
 width: var(--n-indicator-icon-size);
 height: var(--n-indicator-icon-size);
 font-size: var(--n-indicator-icon-size);
 line-height: var(--n-indicator-icon-size);
 `,[z("index",`
 display: inline-block;
 text-align: center;
 position: absolute;
 left: 0;
 top: 0;
 white-space: nowrap;
 font-size: var(--n-indicator-index-font-size);
 width: var(--n-indicator-icon-size);
 height: var(--n-indicator-icon-size);
 line-height: var(--n-indicator-icon-size);
 color: var(--n-indicator-text-color);
 transition: color .3s var(--n-bezier);
 `,[C()]),i("icon",`
 color: var(--n-indicator-text-color);
 transition: color .3s var(--n-bezier);
 `,[C()]),i("base-icon",`
 color: var(--n-indicator-text-color);
 transition: color .3s var(--n-bezier);
 `,[C()])])]),y("vertical","flex-direction: column;",[Q("show-description",[m(">",[i("step","padding-bottom: 8px;")])]),m(">",[i("step","margin-bottom: 16px;",[m("&:last-child","margin-bottom: 0;"),m(">",[i("step-indicator",[m(">",[i("step-splitor",`
 position: absolute;
 bottom: -8px;
 width: 1px;
 margin: 0 !important;
 left: calc(var(--n-indicator-size) / 2);
 height: calc(100% - var(--n-indicator-size));
 `)])]),i("step-content",[z("description","margin-top: 8px;")])])])])])]);function xe(e,r){return typeof e!="object"||e===null||Array.isArray(e)?null:(e.props||(e.props={}),e.props.internalIndex=r+1,e)}function me(e){return e.map((r,o)=>xe(r,o))}const ge=Object.assign(Object.assign({},E.props),{current:Number,status:{type:String,default:"process"},size:{type:String,default:"medium"},vertical:Boolean,"onUpdate:current":[Function,Array],onUpdateCurrent:[Function,Array]}),U=ee("n-steps"),_e=$({name:"Steps",props:ge,setup(e,{slots:r}){const{mergedClsPrefixRef:o,mergedRtlRef:t}=F(e),p=X("Steps",t,o),l=E("Steps","-steps",ve,te,e,o);return Y(U,{props:e,mergedThemeRef:l,mergedClsPrefixRef:o,stepsSlots:r}),{mergedClsPrefix:o,rtlEnabled:p}},render(){const{mergedClsPrefix:e}=this;return s("div",{class:[`${e}-steps`,this.rtlEnabled&&`${e}-steps--rtl`,this.vertical&&`${e}-steps--vertical`]},me(Z(fe(this))))}}),be={status:String,title:String,description:String,disabled:Boolean,internalIndex:{type:Number,default:0}},ze=$({name:"Step",props:be,setup(e){const r=se(U,null);r||ne("step","`n-step` must be placed inside `n-steps`.");const{inlineThemeDisabled:o}=F(),{props:t,mergedThemeRef:p,mergedClsPrefixRef:l,stepsSlots:c}=r,u=b(()=>t.vertical),_=b(()=>{const{status:n}=e;if(n)return n;{const{internalIndex:a}=e,{current:x}=t;if(x===void 0)return"process";if(a<x)return"finish";if(a===x)return t.status||"process";if(a>x)return"wait"}return"process"}),k=b(()=>{const{value:n}=_,{size:a}=t,{common:{cubicBezierEaseInOut:x},self:{stepHeaderFontWeight:A,[d("stepHeaderFontSize",a)]:H,[d("indicatorIndexFontSize",a)]:K,[d("indicatorSize",a)]:M,[d("indicatorIconSize",a)]:O,[d("indicatorTextColor",n)]:W,[d("indicatorBorderColor",n)]:D,[d("headerTextColor",n)]:q,[d("splitorColor",n)]:J,[d("indicatorColor",n)]:L,[d("descriptionTextColor",n)]:G}}=p.value;return{"--n-bezier":x,"--n-description-text-color":G,"--n-header-text-color":q,"--n-indicator-border-color":D,"--n-indicator-color":L,"--n-indicator-icon-size":O,"--n-indicator-index-font-size":K,"--n-indicator-size":M,"--n-indicator-text-color":W,"--n-splitor-color":J,"--n-step-header-font-size":H,"--n-step-header-font-weight":A}}),v=o?ie("step",b(()=>{const{value:n}=_,{size:a}=t;return`${n[0]}${a[0]}`}),k,t):void 0,V=b(()=>{if(e.disabled)return;const{onUpdateCurrent:n,"onUpdate:current":a}=t;return n||a?()=>{n&&R(n,e.internalIndex),a&&R(a,e.internalIndex)}:void 0});return{stepsSlots:c,mergedClsPrefix:l,vertical:u,mergedStatus:_,handleStepClick:V,cssVars:o?void 0:k,themeClass:v==null?void 0:v.themeClass,onRender:v==null?void 0:v.onRender}},render(){const{mergedClsPrefix:e,onRender:r,handleStepClick:o,disabled:t}=this,p=T(this.$slots.default,l=>{const c=l||this.description;return c?s("div",{class:`${e}-step-content__description`},c):null});return r==null||r(),s("div",{class:[`${e}-step`,t&&`${e}-step--disabled`,!t&&o&&`${e}-step--clickable`,this.themeClass,p&&`${e}-step--show-description`,`${e}-step--${this.mergedStatus}-status`],style:this.cssVars,onClick:o},s("div",{class:`${e}-step-indicator`},s("div",{class:`${e}-step-indicator-slot`},s(re,null,{default:()=>T(this.$slots.icon,l=>{const{mergedStatus:c,stepsSlots:u}=this;return c==="finish"||c==="error"?c==="finish"?s(N,{clsPrefix:e,key:"finish"},{default:()=>w(u["finish-icon"],()=>[s(he,null)])}):c==="error"?s(N,{clsPrefix:e,key:"error"},{default:()=>w(u["error-icon"],()=>[s(oe,null)])}):null:l||s("div",{key:this.internalIndex,class:`${e}-step-indicator-slot__index`},this.internalIndex)})})),this.vertical?s("div",{class:`${e}-step-splitor`}):null),s("div",{class:`${e}-step-content`},s("div",{class:`${e}-step-content-header`},s("div",{class:`${e}-step-content-header__title`},w(this.$slots.title,()=>[this.title])),this.vertical?null:s("div",{class:`${e}-step-splitor`})),p))}}),g=e=>(de("data-v-fc703c0f"),e=e(),pe(),e),Se={class:"w-full h-full flex justify-center items-center bg-#fff"},ye=g(()=>h("p",{class:"text-#000"},"边缘网关——配网入口",-1)),Ce=g(()=>h("p",{class:"text-#000 opacity-70"},"边缘网关配网入口：“美的商照小程序”-添加设备-智能网关-边缘网关",-1)),we=g(()=>h("p",{class:"text-#000"},"边缘网关——扫码配网",-1)),Ie=g(()=>h("p",{class:"text-#000 opacity-70"},"使用“美的商照小程序扫一扫以下二维码进行配网”",-1)),$e={class:"w-full flex justify-center"},ke=["src"],Re=g(()=>h("p",{class:"text-#000"},"完成配网",-1)),Te=g(()=>h("p",{class:"text-#000 opacity-70"},"边缘网关完成项目配网后，会自动生成本地账号",-1)),Ne=$({__name:"index",setup(e){const r=I(0),o=I("process"),t=I("");let p;return ae(async()=>{const l=await B();l.error||(t.value=l.data.qrcode),p=setInterval(async()=>{const c=await B();c.error||(t.value=c.data.qrcode)},6e4)}),ce(()=>{clearTimeout(p)}),(l,c)=>{const u=ze,_=_e;return P(),j("div",Se,[S(_,{vertical:"",current:r.value,status:o.value},{default:f(()=>[S(u,{title:"边缘网关——配网入口",description:"边缘网关配网入口：“美的商照小程序”-添加设备-智能网关-边缘网关"},{title:f(()=>[ye]),default:f(()=>[Ce]),_:1}),S(u,{title:"边缘网关——扫码配网"},{title:f(()=>[we]),default:f(()=>[Ie,h("div",$e,[t.value?(P(),j("img",{key:0,class:"w-300px h-300px",src:t.value},null,8,ke)):le("",!0)])]),_:1}),S(u,{title:"完成配网",description:"边缘网关完成项目配网后，会自动生成本地账号"},{title:f(()=>[Re]),default:f(()=>[Te]),_:1})]),_:1},8,["current","status"])])}}});const Fe=ue(Ne,[["__scopeId","data-v-fc703c0f"]]);export{Fe as default};
