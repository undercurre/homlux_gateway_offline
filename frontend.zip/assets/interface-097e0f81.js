import{A as t}from"./index-e9a0fbbf.js";const e=t("n-layout-sider"),i={type:String,default:"static"};export{e as l,i as p};
